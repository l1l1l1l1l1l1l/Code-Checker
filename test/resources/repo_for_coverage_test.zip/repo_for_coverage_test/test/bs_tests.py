import unittest


class BinarySearch:
    def __init__(self, given_array=[], given_target_number=0):
        self.array = given_array
        self.target_number = given_target_number
        self.low_index = 0
        self.high_index = len(self.array) - 1
        self.middle = self.find_middle_index()

    def find_middle_index(self):
        return (self.low_index + self.high_index - 1) // 2 + 1

    def search_index_of_target_number(self):
        if len(self.array) == 0:
            return -1
        return self.search_array()

    def search_array(self):
        while -1 < self.low_index <= self.high_index < len(self.array):
            if self.target_number_found():
                return self.middle
            self.update_middle_index()
        return -1

    def target_number_found(self):
        self.middle = self.find_middle_index()
        return self.array[self.middle] == self.target_number

    def update_middle_index(self):
        if self.array[self.middle] > self.target_number:
            self.high_index = self.middle - 1
        else:
            self.low_index = self.middle + 1


class BinarySearchTest(unittest.TestCase):
    def test_empty_array(self):
        empty_array = []
        target_number = 1
        test_search = BinarySearch(empty_array, target_number)
        self.assertEqual(-1, test_search.search_index_of_target_number())

    def test_one_number_array_with_target_number(self):
        one_number_array = [1]
        target_number = 1
        test_search = BinarySearch(one_number_array, target_number)
        self.assertEqual(0, test_search.search_index_of_target_number())

    def test_one_number_array_without_target_number(self):
        one_number_array = [1]
        target_number = 3
        test_search = BinarySearch(one_number_array, target_number)
        self.assertEqual(-1, test_search.search_index_of_target_number())

    def test_two_numbers_array_with_lower_target_number(self):
        two_numbers_array = [1, 3]
        lower_target_number = 1
        test_search = BinarySearch(two_numbers_array, lower_target_number)
        self.assertEqual(0, test_search.search_index_of_target_number())

    def test_two_numbers_array_with_higher_target_number(self):
        two_numbers_array = [1, 3]
        higher_target_number = 3
        test_search = BinarySearch(two_numbers_array, higher_target_number)
        self.assertEqual(1, test_search.search_index_of_target_number())

    def test_two_numbers_array_without_target_number(self):
        two_numbers_array = [1, 3]
        target_number = 2
        test_search = BinarySearch(two_numbers_array, target_number)
        self.assertEqual(-1, test_search.search_index_of_target_number())

    def test_even_numbers_array_with_target_number(self):
        even_numbers_array = [1, 3, 5, 7]
        target_number = 5
        test_search = BinarySearch(even_numbers_array, target_number)
        self.assertEqual(2, test_search.search_index_of_target_number())

    def test_even_numbers_array_without_target_number(self):
        even_numbers_array = [1, 3, 5, 7]
        target_number = 9
        test_search = BinarySearch(even_numbers_array, target_number)
        self.assertEqual(-1, test_search.search_index_of_target_number())

    def test_odd_numbers_array_with_target_number(self):
        odd_numbers_array = [1, 3, 5, 7, 9]
        target_number = 7
        test_search = BinarySearch(odd_numbers_array, target_number)
        self.assertEqual(3, test_search.search_index_of_target_number())

    def test_odd_numbers_array_without_target_number(self):
        odd_numbers_array = [1, 3, 5, 7, 9]
        target_number = 0
        test_search = BinarySearch(odd_numbers_array, target_number)
        self.assertEqual(-1, test_search.search_index_of_target_number())


if __name__ == '__main__':
    unittest.main()
